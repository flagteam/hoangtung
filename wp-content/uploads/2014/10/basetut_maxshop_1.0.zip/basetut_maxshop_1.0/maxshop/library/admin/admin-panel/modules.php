<?php

/**** ADMIN PANEL MODULE ****/

$panelPath =  get_template_directory() . '/library/admin/admin-panel/';

require_once ($panelPath . 'general-settings.php');
require_once ($panelPath . 'sidebars.php');
require_once ($panelPath . 'pricing-tables.php');
?>
