Refer to documentation folder on download package for theme documentation.


* Initial Release (1.0)
